<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    

</head>
<body>
    <h2>test2</h2>

<form action="{{url('/~bdhowcom/test2/')}}" method="POST" id="myForm">
    @csrf
  <label for="name">email:</label>
  <input type="text" id="email" name="email">
  <label for="lname">name:</label>
  <input type="text" id="name" name="name"><br>
  <label for="lname">location:</label>
  <input type="text" id="location" name="location">
  <label for="lname">father:</label>
  <input type="text" id="father" name="father">
  <label for="lname">note:</label>
  <input type="text" id="note" name="note">
  <input type="submit" value="Submit">
</form>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function () {
        // Intercept the form submission
        $("#myForm").on("submit", function (e) {
            e.preventDefault(); // Prevent the default form submission

            // Serialize the form data
            var formData = $(this).serialize();

            // Send an AJAX request
            $.ajax({
                type: "POST", // Use POST method
                url: "{{url('/~bdhowcom/test2/')}}", // Replace with your form submission endpoint
                data: formData,
                success: function (response) {
                    // Clear the form on success
                    $("#myForm")[0].reset();
                    alert(response);
                },
                error: function (error) {
                    console.error("Error:", error);
                    alert(error.responseText);
                }
            });
        });
    });
</script>


</body>
</html>
