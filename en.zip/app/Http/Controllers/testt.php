<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\test2;

class testt extends Controller
{
    public function index(Request $request){
        $r = $request->all();
        try{
        test2::create($r);
        return 'Saved successfully';
        }
        catch (Exception $e) {
            echo 'error';
        }
        
    }
}
