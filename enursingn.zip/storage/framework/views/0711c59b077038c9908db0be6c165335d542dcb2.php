<?php $__env->startSection('content'); ?>


<div class="card card-primary col-11 m-3">

    <?php if(session()->has('success')): ?>
    <p class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

    </p>
<?php endif; ?>
              <div class="card-header">
                <h3 class="card-title">Create question for - <?php echo e($quiz->title); ?> - (<?php echo e($quiz->current_number+1); ?>/<?php echo e($quiz->number); ?>)</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form action="<?php echo e(url('question/add/').'/'.$quiz->id); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="card-body">


                    <div class="form-group">
                        <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <label for="question">Question</label>
                        <input type="text" class="form-control" id="question" name="question" placeholder="Write question">
                      </div>

                  <div class="form-group">
                    <?php $__errorArgs = ['a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="a">Option A</label>
                    <input type="text" class="form-control" id="a" name="a" placeholder="Write Option">
                  </div>
                  <div class="form-group">
                    <?php $__errorArgs = ['b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="b">Option B</label>
                    <input type="text" class="form-control" name="b" id="b" placeholder="Write Option">
                  </div>


                  <div class="form-group">
                    <?php $__errorArgs = ['c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="c">Option C</label>
                    <input type="text" class="form-control" name="c" id="c" placeholder="Write Option">
                  </div>

                  <div class="form-group">
                    <?php $__errorArgs = ['d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="d">Option D</label>
                    <input type="text" class="form-control" name="d" id="d" placeholder="Write Option">
                  </div>

                  <div class="form-group">
                    <label>Select right answer</label>
                    <select class="form-control select2" name="right" style="width: 100%;">

                      <option value="a">A</option>
                      <option value="b">B</option>
                      <option value="c">C</option>
                      <option value="d">D</option>


                    </select>
                  </div>


                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Create Question</button>
                </div>
              </form>
            </div>


            <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-main\enursing\resources\views/questionCreate.blade.php ENDPATH**/ ?>