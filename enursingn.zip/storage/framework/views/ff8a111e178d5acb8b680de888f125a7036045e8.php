<?php $__env->startSection('content'); ?>


<div class="card card-primary col-md-11 mt-2 m-md-3">

    <?php if(session()->has('success')): ?>
    <p class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

    </p>
<?php endif; ?>

    <div class="accordion accordion-group" id="our-values-accordion">





        <table class="table table-bordered" style="font-size: 12px">
            <thead>
              <tr>
                <th scope="col">SL</th>

                <th scope="col">Title</th>
                <th scope="col">Cata.</th>
                <th scope="col">Tot.</th>
                <th scope="col">Now</th>
                <th scope="col">Time</th>
                <th scope="col">Sta.</th>
                <th scope="col">Action</th>

              </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $quiz; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$quz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th scope="row"><?php echo e($key+1); ?></th>
                <td><?php echo e(Str::limit($quz->title,10)); ?> </td>
                <td><?php echo e($quz->catagory); ?></td>
                <td><?php echo e($quz->number); ?></td>
                <td><?php echo e($quz->current_number); ?></td>
                <th><?php echo e($quz->time); ?></th>
                <td><?php if(!($quz->status=='Approved')): ?>
                    <input class="btn btn-primary" style="font-size: 10px; padding:0px;" value="" type="submit" form="form-<?php echo e($quz->id); ?>">
                    <?php endif; ?></td>


                <td>

                    <a href="<?php echo e(url('edit').'/'.$quz->id); ?>" class="text-primary mr-md-2"><i class="fas fa-edit"></i></a>
                <span>   <form method="POST" action="<?php echo e(url('question').'/'.$quz->id); ?>" id="form-<?php echo e($quz->id); ?>" style="display:none">
                        <?php echo csrf_field(); ?>
<?php echo method_field('patch'); ?>

                      </form></span>
                      <button class="btn btn-warning" style="font-size: 10px; text:white; padding:0px;"> <a href="<?php echo e(url('question/add').'/'.$quz->id); ?>" class=" m-1">Add</a> </button>


                   <form method="POST" action="<?php echo e(url('quiz').'/'.$quz->id); ?>" id="delete-form-<?php echo e($quz->id); ?>" style="display:none">
                          <?php echo csrf_field(); ?>
                          <?php echo method_field('DELETE'); ?>

                        </form>
                        <span>      <a href="#" class="delete-icon-link ml-md-2 text-danger" data-record-id="<?php echo e($quz->id); ?>">
                          <i class="fas fa-trash delete-icon"></i>
                        </a></span>
                    </td>

              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>

 <?php echo e($quiz->links()); ?>



    <!--/ Accordion end -->
<br>
  </div>

            </div>


            <script>
                var deleteLinks = document.querySelectorAll('.delete-icon-link');

                deleteLinks.forEach(function(link) {
                  link.addEventListener('click', function(event) {
                    event.preventDefault();
                    var recordId = link.getAttribute('data-record-id');
                    var confirmDelete = confirm('Are you sure you want to delete this record?');

                    if (confirmDelete) {
                      var formId = 'delete-form-' + recordId;
                      var form = document.getElementById(formId);
                      form.submit();
                    }
                  });
                });
              </script>


            <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-main\enursing\resources\views/question.blade.php ENDPATH**/ ?>