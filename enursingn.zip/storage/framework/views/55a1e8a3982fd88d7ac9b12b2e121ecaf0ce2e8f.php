<?php $__env->startSection('content'); ?>


<div class="card card-primary col-11 m-3">

    <?php if(session()->has('success')): ?>
    <p class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

    </p>
<?php endif; ?>
              <div class="card-header">
                <h3 class="card-title">Create a quiz</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form action="<?php echo e(url('quiz')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="card-body">
                    <div class="form-group">
                        <label>Choose catagory</label>
                        <select class="form-control select2" name="catagory" style="width: 100%;">

                          <option value="gen">General</option>
                          <option value="govt">Govt</option>
                          <option value="eng">English</option>
                          <option value="ban">Bangla</option>
                          <option value="math">Math</option>
                          <option value="gk">General knowledge</option>

                        </select>
                      </div>
                  <div class="form-group">
                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="title">Title</label>
                    <input type="text" class="form-control" id="title" name="title" placeholder="Title">
                  </div>
                  <div class="form-group">
                    <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="number">Number of questions</label>
                    <input type="number" class="form-control" name="number" id="number" placeholder="Number of questions">
                  </div>


                  <div class="form-group">
                    <?php $__errorArgs = ['time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="time">Time (In minutes)</label>
                    <input type="number" class="form-control" name="time" id="time" placeholder="Quiz duration">
                  </div>


                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Create Quiz</button>
                </div>
              </form>
            </div>


            <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-main\enursing\resources\views/create.blade.php ENDPATH**/ ?>